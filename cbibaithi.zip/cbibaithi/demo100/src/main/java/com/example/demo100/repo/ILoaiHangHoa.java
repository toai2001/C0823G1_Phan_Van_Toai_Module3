package com.example.demo100.repo;

import com.example.demo100.model.LoaiHangHoa;

import java.util.List;

public interface ILoaiHangHoa {
    List<LoaiHangHoa> hienThiLoaiHangHoa();

}
