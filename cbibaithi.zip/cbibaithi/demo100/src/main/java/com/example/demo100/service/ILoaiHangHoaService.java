package com.example.demo100.service;

import com.example.demo100.model.LoaiHangHoa;

import java.util.List;

public interface ILoaiHangHoaService {
    List<LoaiHangHoa> hienThiLoaiHangHoa();

}
